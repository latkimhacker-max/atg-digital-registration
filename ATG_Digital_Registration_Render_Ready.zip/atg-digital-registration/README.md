# ATG Digital Registration

A responsive membership registration application with dual email/SMS OTP verification, member login, unique member IDs, referral links, PostgreSQL storage and an admin dashboard.

## Important before publishing

This project is a deployable application codebase, not an already-hosted public website. It needs a PostgreSQL database, email/SMS provider credentials and a hosting deployment. Do not publish with example credentials.

## Deploy on Replit

1. Create a new Replit **Node.js** app.
2. Upload/extract this project into the Replit workspace (or upload the ZIP and extract it).
3. Add a PostgreSQL database using Replit's Database tool. Copy its connection string into the `DATABASE_URL` Secret.
4. In Replit **Secrets**, add every required value from `.env.example`:
   - `DATABASE_URL`
   - `SESSION_SECRET` (use a long, random value)
   - `ADMIN_EMAIL`
   - `ADMIN_PASSWORD` (at least 12 characters; never share it)
   - `RESEND_API_KEY`, `EMAIL_FROM`
   - `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER`
5. Configure Resend with a verified sender/domain. Resend's test sender may only deliver to permitted/test recipients.
6. Configure a Twilio phone number that is approved to send SMS in your destination country. Confirm local regulations, sender requirements and pricing.
7. Run `npm install`, then `npm start`.
8. Test registration using email and phone numbers you control. Confirm both codes arrive and that wrong/expired codes do not activate an account.
9. Deploy using Replit Deployments. Set `APP_BASE_URL` to the deployed HTTPS URL and redeploy.

## Phone format

Enter phone numbers in international E.164 format, e.g. `+2348012345678`.

## Admin

Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in Secrets before the first run. The initial admin is created once. The admin login is at the **Admin** button on the site. Keep the admin password private and change it if it is ever exposed.

## Security notes

- Passwords are hashed with bcrypt.
- OTP values are stored as SHA-256 hashes and expire after 10 minutes.
- API endpoints are rate limited.
- Session cookies are HTTP-only and secure in production.
- Database queries are parameterized.
- Admin member export contains personal data. Restrict access and download only when necessary.
- The organisation must publish a privacy notice, explain why it collects each data item, obtain appropriate consent, and provide a way to request correction/deletion.
- Collect only information genuinely needed. Do not collect government ID numbers, precise home addresses, political opinions or sensitive information for ordinary membership registration.
- For members under 18, obtain appropriate parent/guardian involvement and do not publicly expose their details.
- This starter does not yet include password reset, member deletion workflow, admin audit logs, CAPTCHA, or automated OTP resend. Add and test these before a large public launch.
