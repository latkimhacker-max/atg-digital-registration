require("dotenv").config();

const express = require("express");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes("localhost")
    ? { rejectUnauthorized: false } : false
});

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"]
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be set to a random string of at least 32 characters.");
  process.exit(1);
}
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is required. Add a PostgreSQL database in Replit.");
  process.exit(1);
}

app.use(session({
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

app.use(express.static(path.join(__dirname, "public")));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: "draft-7", legacyHeaders: false }));

const clean = (v, max = 160) => String(v || "").trim().slice(0, max);
const emailOk = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const phoneOk = v => /^\+[1-9]\d{7,14}$/.test(v);
const makeCode = () => crypto.randomBytes(4).toString("hex").toUpperCase();
const otp = () => String(crypto.randomInt(100000, 1000000));
const sha = v => crypto.createHash("sha256").update(v).digest("hex");

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS members (
      id BIGSERIAL PRIMARY KEY,
      member_code TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      referral_code TEXT UNIQUE NOT NULL,
      referred_by BIGINT REFERENCES members(id),
      email_verified BOOLEAN NOT NULL DEFAULT FALSE,
      phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS pending_registrations (
      id BIGSERIAL PRIMARY KEY,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      referral_code TEXT,
      email_otp_hash TEXT NOT NULL,
      phone_otp_hash TEXT NOT NULL,
      email_expires TIMESTAMPTZ NOT NULL,
      phone_expires TIMESTAMPTZ NOT NULL,
      email_verified BOOLEAN NOT NULL DEFAULT FALSE,
      phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS admins (
      id BIGSERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS user_sessions (
      sid VARCHAR NOT NULL COLLATE "default",
      sess JSON NOT NULL,
      expire TIMESTAMP(6) NOT NULL
    );
    CREATE INDEX IF NOT EXISTS user_sessions_expire_idx ON user_sessions(expire);
  `);

  const adminEmail = clean(process.env.ADMIN_EMAIL, 200).toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD || "";
  if (adminEmail && emailOk(adminEmail) && adminPassword.length >= 12) {
    const exists = await pool.query("SELECT id FROM admins WHERE email=$1", [adminEmail]);
    if (!exists.rowCount) {
      const hash = await bcrypt.hash(adminPassword, 12);
      await pool.query("INSERT INTO admins(email,password_hash) VALUES($1,$2)", [adminEmail, hash]);
      console.log("Initial admin account created.");
    }
  } else {
    console.warn("Set ADMIN_EMAIL and an ADMIN_PASSWORD of at least 12 characters to create the admin account.");
  }
}

async function sendEmailCode(to, code) {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) {
    throw new Error("Email delivery is not configured. Add RESEND_API_KEY and EMAIL_FROM.");
  }
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM,
      to: [to],
      subject: "Your ATG registration verification code",
      text: `Your ATG verification code is ${code}. It expires in 10 minutes. If you did not request this, ignore this email.`
    })
  });
  if (!response.ok) throw new Error("Email provider could not send the verification code.");
}

async function sendSmsCode(to, code) {
  const { TWILIO_ACCOUNT_SID: sid, TWILIO_AUTH_TOKEN: token, TWILIO_FROM_NUMBER: from } = process.env;
  if (!sid || !token || !from) throw new Error("SMS delivery is not configured. Add your Twilio credentials.");
  const body = new URLSearchParams({
    To: to, From: from,
    Body: `Your ATG registration verification code is ${code}. It expires in 10 minutes.`
  });
  const auth = Buffer.from(`${sid}:${token}`).toString("base64");
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  if (!response.ok) throw new Error("SMS provider could not send the verification code.");
}

async function requireMember(req, res, next) {
  if (!req.session.memberId) return res.status(401).json({ error: "Please sign in first." });
  const result = await pool.query(
    "SELECT id,member_code,full_name,email,phone,referral_code,created_at FROM members WHERE id=$1",
    [req.session.memberId]
  );
  if (!result.rowCount) { req.session.destroy(() => {}); return res.status(401).json({ error: "Please sign in again." }); }
  req.member = result.rows[0];
  next();
}
async function requireAdmin(req, res, next) {
  if (!req.session.adminId) return res.status(401).json({ error: "Admin sign-in required." });
  next();
}

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, message: { error: "Too many attempts. Please wait and try again." } });

app.post("/api/register", authLimiter, async (req, res) => {
  try {
    const fullName = clean(req.body.fullName, 100);
    const email = clean(req.body.email, 200).toLowerCase();
    const phone = clean(req.body.phone, 20);
    const password = String(req.body.password || "");
    const referralCode = clean(req.body.referralCode, 30).toUpperCase() || null;
    if (fullName.length < 2 || !emailOk(email) || !phoneOk(phone) || password.length < 10) {
      return res.status(400).json({ error: "Enter your name, a valid email, an international phone number (for example +2348012345678), and a password of at least 10 characters." });
    }
    if (await pool.query("SELECT id FROM members WHERE email=$1 OR phone=$2", [email, phone]).then(r => r.rowCount)) {
      return res.status(409).json({ error: "An account with that email or phone already exists." });
    }
    if (referralCode && !(await pool.query("SELECT id FROM members WHERE referral_code=$1", [referralCode])).rowCount) {
      return res.status(400).json({ error: "That referral code was not found. Check it or leave the field blank." });
    }

    const emailCode = otp(), phoneCode = otp();
    const passwordHash = await bcrypt.hash(password, 12);
    const expiry = new Date(Date.now() + 10 * 60 * 1000);
    await pool.query(
      `INSERT INTO pending_registrations
       (full_name,email,phone,password_hash,referral_code,email_otp_hash,phone_otp_hash,email_expires,phone_expires)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$8)
       ON CONFLICT(email) DO UPDATE SET full_name=EXCLUDED.full_name,phone=EXCLUDED.phone,
       password_hash=EXCLUDED.password_hash,referral_code=EXCLUDED.referral_code,
       email_otp_hash=EXCLUDED.email_otp_hash,phone_otp_hash=EXCLUDED.phone_otp_hash,
       email_expires=EXCLUDED.email_expires,phone_expires=EXCLUDED.phone_expires,
       email_verified=FALSE,phone_verified=FALSE`,
      [fullName,email,phone,passwordHash,referralCode,sha(emailCode),sha(phoneCode),expiry]
    );
    try {
      await sendEmailCode(email, emailCode);
      await sendSmsCode(phone, phoneCode);
    } catch (deliveryError) {
      await pool.query("DELETE FROM pending_registrations WHERE email=$1", [email]);
      return res.status(503).json({ error: deliveryError.message });
    }
    res.json({ message: "Verification codes sent. Check your email and phone." });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Registration could not be started. Please try again." });
  }
});

app.post("/api/verify", authLimiter, async (req, res) => {
  try {
    const email = clean(req.body.email, 200).toLowerCase();
    const emailCode = clean(req.body.emailCode, 6);
    const phoneCode = clean(req.body.phoneCode, 6);
    const result = await pool.query("SELECT * FROM pending_registrations WHERE email=$1", [email]);
    if (!result.rowCount) return res.status(404).json({ error: "Registration not found. Please register again." });
    const p = result.rows[0];
    if (new Date(p.email_expires) < new Date() || new Date(p.phone_expires) < new Date()) {
      await pool.query("DELETE FROM pending_registrations WHERE id=$1", [p.id]);
      return res.status(400).json({ error: "Your codes have expired. Please register again." });
    }
    if (sha(emailCode) !== p.email_otp_hash || sha(phoneCode) !== p.phone_otp_hash) {
      return res.status(400).json({ error: "One or both verification codes are incorrect." });
    }
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const ref = p.referral_code
        ? await client.query("SELECT id FROM members WHERE referral_code=$1", [p.referral_code])
        : { rows: [] };
      const referral = ref.rows[0]?.id || null;
      const memberCode = `ATG-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`;
      const referralId = makeCode();
      const inserted = await client.query(
        `INSERT INTO members(member_code,full_name,email,phone,password_hash,referral_code,referred_by,email_verified,phone_verified)
         VALUES($1,$2,$3,$4,$5,$6,$7,TRUE,TRUE) RETURNING id`,
        [memberCode,p.full_name,p.email,p.phone,p.password_hash,referralId,referral]
      );
      await client.query("DELETE FROM pending_registrations WHERE id=$1", [p.id]);
      await client.query("COMMIT");
      req.session.memberId = inserted.rows[0].id;
      res.json({ message: "Your account is verified and active.", memberCode });
    } catch (e) {
      await client.query("ROLLBACK");
      if (e.code === "23505") return res.status(409).json({ error: "That email or phone is already registered." });
      throw e;
    } finally { client.release(); }
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Verification could not be completed." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  try {
    const email = clean(req.body.email, 200).toLowerCase();
    const password = String(req.body.password || "");
    const r = await pool.query("SELECT id,password_hash FROM members WHERE email=$1", [email]);
    if (!r.rowCount || !(await bcrypt.compare(password, r.rows[0].password_hash))) {
      return res.status(401).json({ error: "Email or password is incorrect." });
    }
    req.session.memberId = r.rows[0].id;
    res.json({ message: "Signed in." });
  } catch (e) { res.status(500).json({ error: "Sign-in failed." }); }
});

app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ message: "Signed out." })));

app.get("/api/me", requireMember, async (req, res) => {
  const count = await pool.query("SELECT COUNT(*)::int AS total FROM members WHERE referred_by=$1", [req.member.id]);
  const base = process.env.APP_BASE_URL || `${req.protocol}://${req.get("host")}`;
  res.json({ ...req.member, referralLink: `${base}/?ref=${req.member.referral_code}`, referralCount: count.rows[0].total });
});

app.post("/api/admin/login", authLimiter, async (req, res) => {
  try {
    const email = clean(req.body.email, 200).toLowerCase();
    const r = await pool.query("SELECT id,password_hash FROM admins WHERE email=$1", [email]);
    if (!r.rowCount || !(await bcrypt.compare(String(req.body.password || ""), r.rows[0].password_hash))) {
      return res.status(401).json({ error: "Admin email or password is incorrect." });
    }
    req.session.adminId = r.rows[0].id;
    res.json({ message: "Admin signed in." });
  } catch (e) { res.status(500).json({ error: "Admin sign-in failed." }); }
});

app.get("/api/admin/summary", requireAdmin, async (req, res) => {
  const [total, recent, refs] = await Promise.all([
    pool.query("SELECT COUNT(*)::int AS n FROM members"),
    pool.query("SELECT COUNT(*)::int AS n FROM members WHERE created_at > NOW()-INTERVAL '7 days'"),
    pool.query("SELECT COUNT(*)::int AS n FROM members WHERE referred_by IS NOT NULL")
  ]);
  res.json({ total: total.rows[0].n, recent: recent.rows[0].n, referred: refs.rows[0].n });
});

app.get("/api/admin/members", requireAdmin, async (req, res) => {
  const q = `%${clean(req.query.q, 80)}%`;
  const r = await pool.query(
    `SELECT m.member_code,m.full_name,m.email,m.phone,m.referral_code,m.created_at,
      COALESCE(ref.full_name,'') AS referred_by
     FROM members m LEFT JOIN members ref ON ref.id=m.referred_by
     WHERE m.full_name ILIKE $1 OR m.email ILIKE $1 OR m.member_code ILIKE $1
     ORDER BY m.created_at DESC LIMIT 300`, [q]
  );
  res.json(r.rows);
});

app.get("/api/admin/export.csv", requireAdmin, async (req, res) => {
  const r = await pool.query(
    `SELECT member_code,full_name,email,phone,referral_code,created_at FROM members ORDER BY created_at DESC`
  );
  const cell = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const csv = ["Member ID,Full name,Email,Phone,Referral code,Joined",
    ...r.rows.map(x => [x.member_code,x.full_name,x.email,x.phone,x.referral_code,x.created_at.toISOString()].map(cell).join(","))].join("\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=atg-members.csv");
  res.send(csv);
});

app.get("/api/admin/status", requireAdmin, (req, res) => res.json({ ok: true }));

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

initDb().then(() => app.listen(PORT, "0.0.0.0", () => console.log(`ATG platform listening on ${PORT}`)))
  .catch(err => { console.error("Database startup failed:", err); process.exit(1); });
