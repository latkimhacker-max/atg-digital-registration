const $ = s => document.querySelector(s);
const toast = message => { const t=$("#toast"); t.textContent=message; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),3500); };
async function api(url, options={}) {
  const r=await fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||"Something went wrong.");
  return data;
}
const showModal=id=>$("#"+id).classList.remove("hidden");
const closeModals=()=>document.querySelectorAll(".modal").forEach(x=>x.classList.add("hidden"));
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",closeModals));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModals()}));
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>showModal(({login:"loginModal",admin:"adminModal"})[b.dataset.view])));
$("#year").textContent=new Date().getFullYear();
const ref=new URLSearchParams(location.search).get("ref"); if(ref) $("#referralCode").value=ref;

$("#registerForm").addEventListener("submit",async e=>{
  e.preventDefault(); const data=Object.fromEntries(new FormData(e.target));
  try { await api("/api/register",{method:"POST",body:JSON.stringify(data)}); $("#verifyEmail").value=data.email; showModal("verifyModal"); toast("Verification codes sent."); }
  catch(err){toast(err.message)}
});
$("#verifyForm").addEventListener("submit",async e=>{
  e.preventDefault(); const data=Object.fromEntries(new FormData(e.target));
  try { const result=await api("/api/verify",{method:"POST",body:JSON.stringify(data)}); closeModals(); toast(result.message); await loadMember(); }
  catch(err){toast(err.message)}
});
$("#loginForm").addEventListener("submit",async e=>{
  e.preventDefault(); try { await api("/api/login",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}); closeModals(); await loadMember(); }
  catch(err){toast(err.message)}
});
async function loadMember(){
  try { const m=await api("/api/me"); $("#memberPanel").classList.remove("hidden"); $("#memberCode").textContent=m.member_code; $("#refCount").textContent=m.referralCount; $("#refLink").value=m.referralLink; $("#memberName").textContent=`Welcome, ${m.full_name}`; $("#memberPanel").scrollIntoView({behavior:"smooth"}); }
  catch(e){ $("#memberPanel").classList.add("hidden"); }
}
$("#logoutBtn").addEventListener("click",async()=>{await api("/api/logout",{method:"POST"});$("#memberPanel").classList.add("hidden");toast("Signed out.");});
$("#copyRef").addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("#refLink").value);toast("Referral link copied.");}catch(e){$("#refLink").select();toast("Select and copy your link.");}});
$("#adminLoginForm").addEventListener("submit",async e=>{
  e.preventDefault(); try {await api("/api/admin/login",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}); e.target.classList.add("hidden");$("#adminDashboard").classList.remove("hidden");await loadAdmin();toast("Admin dashboard opened.");}
  catch(err){toast(err.message)}
});
async function loadAdmin(){
  const s=await api("/api/admin/summary");$("#totalMembers").textContent=s.total;$("#recentMembers").textContent=s.recent;$("#referredMembers").textContent=s.referred;await loadMembers();
}
async function loadMembers(){
  const rows=await api("/api/admin/members?q="+encodeURIComponent($("#memberSearch").value||""));
  $("#membersTable").innerHTML=rows.map(m=>`<tr><td>${esc(m.full_name)}</td><td>${esc(m.email)}</td><td>${esc(m.phone)}</td><td>${esc(m.member_code)}</td><td>${esc(m.referred_by||"—")}</td></tr>`).join("")||"<tr><td colspan='5'>No members found.</td></tr>";
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
let searchTimer;$("#memberSearch").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>loadMembers().catch(e=>toast(e.message)),250)});
loadMember();
